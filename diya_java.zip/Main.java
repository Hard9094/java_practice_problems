package com.company;

    public class Main{
        public static void main(String[]args)
        {
            System.out.println("sum of the numbers is");
            int num1= 1;
            int num2= 2;
            int num3= 3;
            int sum= num1 + num2 + num3 ;
            System.out.println(sum);
        }

}
