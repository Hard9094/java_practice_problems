package com.company;

public class Operators_practice2 {
    public static void main(String[]args)
    {
        char grade = 'A';
        grade = (char)(grade + 8);
        System.out.println(grade);

        //decrypt the code
        grade = (char)(grade - 8);
        System.out.println(grade);
    }
}
