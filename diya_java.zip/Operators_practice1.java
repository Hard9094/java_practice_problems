package com.company;

public class Operators_practice1 {
    public static void main(String[]args)
    {
        float a = 7/4.0f*9/2.0f ;
        System.out.println(a);
    }
}
