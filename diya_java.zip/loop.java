package com.company;
import java.util.Scanner;

public class loop {
    public static void main(String[]args) {
        //  int i=100;
        // while(i<=200){
        //  System.out.println(i);
        // i++;

        //}
       // Scanner sc = new Scanner(System.in);
       // System.out.println("enter n ");
       // int n = sc.nextInt();
        //int i = 1;
        //do {
        //  System.out.println(i);
        //i++;
        // while (i <= n);

        //int b = 10;
        //do {
        //  System.out.println(b);
        //b++;
        //} while (b < 5);
        int i ;
        int n=5;
        for (i = 0; i <5; i++) {
            System.out.println(2*i+1);
        }
    }
}
