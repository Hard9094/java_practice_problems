package com.company;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class collections {
    public static void main(String[]args)
    {
        //ArrayList
       // Set
       // TreeSet
    }
}
