package com.company;
 class sphere{}

public class access_practice5 {
}
