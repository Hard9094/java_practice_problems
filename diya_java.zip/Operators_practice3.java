package com.company;
import java.util.Scanner;

public class Operators_practice3 {
    public static void main(String[]args)
    {
        int a= 56;
        Scanner num = new Scanner(System.in);
        System.out.println("enter a num");
        int b = num.nextInt();
        System.out.println(a>b);
    }
}
