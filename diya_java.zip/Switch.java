package com.company;

public class Switch {
    public static void main(String[]args)
    {
        int var = 1;

        switch (var){
            case 1:
                System.out.println("you are first!!");
                break;

            case 2:
                System.out.println("you are second");
                break;

            default:
                System.out.println("does not exist");

    }

    }
}
