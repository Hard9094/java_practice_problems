package com.company;

public class String_practice5 {
    public static void main(String[]args)
    {
        String letter = "Dear Harry,\n\t This java course is nice.\n\tThanks";
        System.out.println(letter);
    }
}
