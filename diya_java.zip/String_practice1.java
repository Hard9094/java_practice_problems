package com.company;

public class String_practice1 {
    public static void main(String[]args)
    {
        String name = "DIYA MODI";
        System.out.println(name.toLowerCase());
    }


}
