package com.company;

public class Conditionals {
    public static void main(String[]args)
    {
        int age = 16;
        if(age>18){
            System.out.println("yes boy you can drive");
        }
        else{
            System.out.println("no boy not yet");
        }

    }
}
