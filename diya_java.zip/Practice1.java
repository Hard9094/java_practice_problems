package com.company;


public class Practice1 {
    public static void main(String[]args)
    {
        int a= 12;
        int b= 12;
        int c= 12;
        int sum = a + b +c;
        System.out.println("the answer is"+ sum);
    }
}
