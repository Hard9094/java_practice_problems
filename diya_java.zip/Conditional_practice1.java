package com.company;

public class Conditional_practice1 {
    public static void main(String[]args)
    {
        int a= 10;
        if(a==11)
        {
            System.out.println("i am 11");
        }
        else{
            System.out.println("i am not 11");
        }
    }
}
