package com.company;

public class loop_practice3 {
    public static void main(String[]args)
    {
        int n=4,mul;
        for( int i=1;i<=10;i++)
        {
            mul= n*i;
            System.out.println(" 4 X   ="+mul);

        }
    }
}
