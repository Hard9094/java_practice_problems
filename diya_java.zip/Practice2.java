package com.company;

public class Practice2 {
    public static void main(String[]args)
    {
        int sub1= 45;
        int sub2= 45;
        int sub3= 45;
        float CGPA=(sub1 + sub2 + sub3)/30;
        System.out.println("the answer is"+ CGPA);
    }
}
