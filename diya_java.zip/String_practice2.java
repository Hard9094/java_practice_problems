package com.company;

public class String_practice2 {
    public static void main(String[]args)
    {
        String name = "rabba   mehar   kari";
        System.out.println(name.replace("   ", "___"));
    }
}
