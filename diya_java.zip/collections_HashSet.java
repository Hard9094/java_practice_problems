package com.company;

import java.util.HashSet;

public class collections_HashSet {
    public static void main(String[]args)
    {
        HashSet<Integer> h1 = new HashSet<>(6,0.5f);
        h1.add(5);
        h1.add(6);
        h1.add(46);
        h1.add(47);
        System.out.println(h1);
    }
}
