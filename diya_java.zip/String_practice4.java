package com.company;

public class String_practice4  {
    public static void main(String[]args)
    {
        String line = "there are  two people";
        System.out.println(line.indexOf("  "));
        System.out.println(line.indexOf("   "));
    }
}
